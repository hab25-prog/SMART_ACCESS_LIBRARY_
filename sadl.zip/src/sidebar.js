import React from "react";
import {
  FaFolderOpen,
  FaCogs,
  FaHome,
  FaUpload,
  FaUserCog,
  FaUser,
} from "react-icons/fa";

export default function SideBar({ nav }) {
  return (
    <div className="sidebar">
      <h1 className="logo">SMART ACCESS</h1>
      <div className="flex items-center space-x-2 user">
        <FaUser size={24} color="#4A5568" />
        <span>Welcome, Habte</span>
      </div>
      <ul>
        <li onClick={() => nav("main")}>
          <FaHome className="icon" /> Home
        </li>
        <li onClick={() => nav("upload")}>
          <FaUpload className="icon" /> Upload
        </li>
        <li onClick={() => nav("browser")}>
          <FaFolderOpen className="icon" /> Browse
        </li>
        <li onClick={() => nav("setting")}>
          <FaCogs className="icon" /> Settings
        </li>
        <li onClick={() => nav("manage")}>
          <FaUserCog className="icon" /> Manage Users
        </li>
      </ul>
    </div>
  );
}
